#include <stdio.h>

int main(){
	printf("Hello, KNU~\n");
	return 0;
}
